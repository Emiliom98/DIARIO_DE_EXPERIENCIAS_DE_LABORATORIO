﻿using System;

namespace Reto2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Actividad No. 2");
            Console.WriteLine("Escriba hasta que estrofa quiere llegar");
            int x = 0;
            int y;
            y = Convert.ToInt16(Console.ReadLine());
      
            while (x <= y)
            {
                if (x == 1)
                {
                    Console.WriteLine("On the first day of Christmas,  On the first day of Christmas, my true love sent to me A partridge in a pear tree. ");
                }
                else if (x == 2)
                {
                    Console.WriteLine("On the second day of Christmas, my true love sent to me Two turtle doves And a partridge in a pear tree. ");
                }
                else if (x == 3)
                {
                    Console.WriteLine("On the third day of Christmas, my true love sent to me Three French hens,Two turtledoves And a partridge in a pear tree. ");
                }
                else if (x == 4)
                {
                    Console.WriteLine("On the fourth day of Christmas, my true love sent to me Four calling birds, Three French hens, Two turtle doves And a partridge in a pear tree. ");
                }
                else if (x == 5)
                {
                    Console.WriteLine("On the fifth day of Christmas, my true love sent to me Five golden rings, Four calling birds, Three French hens, Two turtle doves And a partridge in a pear tree. ");
                }
                else if (x == 6)
                {
                    Console.WriteLine("On the sixth day of Christmas, my true love sent to me Six geese a - laying, Five golden rings, Four calling birds, Three French hens, Two turtle doves And a partridge in a pear tree.");
                }
                else if (x == 7)
                {
                    Console.WriteLine("On the seventh day of Christmas, my true love sent to me Seven swans a - swimming, Six geese a - laying, Five golden rings, Four calling birds, Three French hens, Two turtle doves And a partridge in a pear tree. ");
                }
                else if (x == 8)
                {
                    Console.WriteLine("On the eighth day of Christmas, my true love sent to me Eight maids a - milking, Seven swans a - swimming, Six geese a - laying, Five golden rings, Four calling birds, Three French hens, Two turtle doves And a partridge in a pear tree. ");
                }
                else if (x == 9)
                {
                    Console.WriteLine("On the ninth day of Christmas, my true love sent to me Nine ladies dancing, Eight maids a - milking, Seven swans a - swimming, Six geese a - laying, Five golden rings, Four calling birds, Three French hens, Two turtle doves And a partridge in a pear tree. ");
                }
                else if (x == 10)
                {
                    Console.WriteLine("On the tenth day of Christmas, my true love sent to me Ten lords a - leaping, Nine ladies dancing, Eight maids a - milking, Seven swans a - swimming, Six geese a - laying, Five golden rings, Four calling birds, Three French hens, Two turtle doves And a partridge in a pear tree.");
                }
                else if (x == 11)
                {
                    Console.WriteLine("On the eleventh day of Christmas, my true love sent to me Eleven pipers piping, Ten lords a - leaping, Nine ladies dancing, Eight maids a - milking, Seven swans a - swimming, Six geese a - laying, Five golden rings, Four calling birds, Three French hens, Two turtle doves And a partridge in a pear tree. ");
                }
                else if (x == 12)
                {
                    Console.WriteLine("On the twelfth day of Christmas, my true love sent to me Twelve drummers drumming, Eleven pipers piping, Ten lords a - leaping, Nine ladies dancing, Eight maids a - milking, Seven swans a - swimming, Six geese a - laying, Five golden rings, Four calling birds, Three French hens, Two turtle doves And a partridge in a pear tree!");
                }
                else if (x == 13)
                {
                    Console.WriteLine("END");
                }
                x++;
            }
        }
    }
}
