﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjerciciosClase
{
    class Program
        //Carlos Navajas 1128121 y Emilio Morales 1030921
    {
        static void Main(string[] args)
        {
            int [] vector =new int [5];
            int[] adultos = new int[5];
            int [] ninos = new int[5];
            int[] responsables = new int[5];
            int mayor = 0, level =0, cant=0, n=0;
            Console.WriteLine("Reto No. 1");
            for (int i = 0; i < vector.Length; i++)
            {
                n = i + 1;
                Console.WriteLine("Ingrese la cantidad de personas que vive en el nivle " +n);
                vector[i] = Convert.ToInt32(Console.ReadLine()); 
            }
            for (int i = 0; i < 5; i++)
            {
                if (i == 0)
                {
                    mayor = vector[i];
                    level = i + 1;
                }
                else
                {
                    if (mayor < vector[i])
                    {
                        mayor = vector[i];
                        level = i + 1; 
                    }
                }
            }
            Console.WriteLine("EL nivel con mas personas es: " + level); 
            for (int i = 0; i < 5; i++)
            {
                cant += vector[i];
            }
            Console.WriteLine("La cantidad de personas que vive en el edificio es: " + cant); 
            for (int i=0; i<5; i++)
            {
                n = i + 1;
                Console.WriteLine("Nivel: " +n + " Personas: " + vector[i]); 
            }
            Console.WriteLine("Reto No. 2");
            for (int i=0; i<5; i++)
            {
                n = i + 1;
                Console.WriteLine("Ingrese la cantidad de adultos que vive en el nivle " +n);
                adultos[i] = Convert.ToInt32(Console.ReadLine());
            }
            for (int i = 0; i < 5; i++)
            {
                n = i + 1;
                Console.WriteLine("Ingrese la cantidad de ninos que vive en el nivle " +n);
                ninos[i] = Convert.ToInt32(Console.ReadLine());
            }
            int cantAdultos = 0;
            for (int i = 0; i < 5; i++)
            {
                cantAdultos += adultos[i];
            }
            Console.WriteLine("La cantidad de adultos es: " + cantAdultos);
            int cantNinos = 0;
            for (int i = 0; i < 5; i++)
            {
                cantNinos += ninos[i];
            }
            Console.WriteLine("La cantidad de adultos es: " + cantNinos);
            for(int i = 0; i < 5; i++)
            {
                n = i + 1;
                Console.WriteLine("Nivel: "+n+" Adultos: "+adultos+" Ninos: "+ninos);
            }
            Console.WriteLine("Reto No. 3");
            for (int i = 0; i < 5; i++)
            {
                n = i + 1;
                Console.WriteLine("Ingrese la cantidad de adultos que vive en el nivle "+n);
                adultos[i] = Convert.ToInt32(Console.ReadLine());
            }
            for (int i = 0; i < 5; i++)
            {
                n = i + 1;
                Console.WriteLine("Ingrese la cantidad de ninos que vive en el nivle "+n);
                ninos[i] = Convert.ToInt32(Console.ReadLine());
            }
            for (int i = 0; i < 5; i++)
            {
                n = i + 1;
                Console.WriteLine("Ingrese la cantidad responsables que vive en el nivle " +n);
                responsables[i] = Convert.ToInt32(Console.ReadLine());
            }
            for (int i = 0; i < 5; i++)
            {
                n = i + 1;
                Console.WriteLine("Nivel: " +n + " Adultos: " + adultos + " Ninos: " + ninos+" Responsables"+responsables);
            }
            int ninosMayor = 0;
            level = 0;
            for (int i = 0; i < 5; i++)
            {
                if (i == 0)
                {
                    ninosMayor = ninos[i];
                    level =  i;
                }
                else
                {
                    if (ninosMayor < ninos[i])
                    {
                        ninosMayor = ninos[i];
                        level = i;
                    }
                }
            }
            Console.WriteLine("En el nivel con mas ninos hay: " + responsables[level]); 



            Console.ReadKey();
        }
    }
}
