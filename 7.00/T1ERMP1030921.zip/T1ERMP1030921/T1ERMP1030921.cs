﻿using System;

namespace T1ERMP1030921
{
    class Program
    {
        static void Main(string[] args)
        {
			Console.WriteLine("Introduce tu nombre:");
			string nombre = Console.ReadLine();
			Console.WriteLine("Introduce tu edad:");
			string edad = Console.ReadLine();
			Console.WriteLine("Introduce tu carrera:");
			string carrera = Console.ReadLine();
			Console.WriteLine("Introduce tu carné:");
			string carne = Console.ReadLine();
			Console.WriteLine("Soy " + nombre + ", tengo " + edad + " años. Estudio la carrera de " + carrera + ", y mi número de carné es: " + carne);
			Console.ReadKey();
		}
    }
}
