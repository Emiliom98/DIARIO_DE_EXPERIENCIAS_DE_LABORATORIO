﻿using System;

namespace Laboratorio_7_Emilio_Morales_1030921
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                static void Main(string[] args)
                {
                    int numentero;
             Console.WriteLine("Ejercicio 2");
                    Console.WriteLine("Ingrese un numero del 1 al 7");

                    numentero = Convert.ToInt32(Console.ReadLine());

                    if (numentero == 1)
                    {
                        Console.WriteLine("Lunes");
                    }
                    if (numentero == 2)
                    {
                        Console.WriteLine("Martes");
                    }
                    if (numentero == 3)
                    {
                        Console.WriteLine("Miercoles");
                    }
                    if (numentero == 4)
                    {
                        Console.WriteLine("Jueves");
                    }
                    if (numentero == 5)
                    {
                        Console.WriteLine("viernes");
                    }
                    if (numentero == 6)
                    {
                        Console.WriteLine("Sabado");
                    }
                    if (numentero == 7)
                    {
                        Console.WriteLine("Domingo");
                    }
                }
            }
        }
    }
    
}
