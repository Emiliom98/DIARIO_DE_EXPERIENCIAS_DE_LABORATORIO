﻿using System;

namespace Laboratorio_5_Emilio_Morales
{
    class Program
    {
        static void Main(string[] args)
        {
            int numentero;
            
             Console.WriteLine("Ejercicio 1");
            Console.WriteLine("Ingrese un numero entero");
           
            numentero = Convert.ToInt32(Console.ReadLine());

            if (numentero > 0)
            {
                Console.WriteLine("El num es positivo");
            }
            if (numentero < 0)
            {
                Console.WriteLine("El num es negativo");
            }
            if (numentero == 0)
            {
                Console.WriteLine("es igual a 0");
            }
        }
    }
}
